"use client"

import type React from "react"

import { useState } from "react"

export default function DeviceManagementContent() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false)
  const [editingDevice, setEditingDevice] = useState<any>(null)
  const [deletingDevice, setDeletingDevice] = useState<any>(null)
  const [devices, setDevices] = useState([
    {
      id: "DEV001",
      name: "Sensor Hub Alpha",
      model: "SH-2000",
      serialNumber: "SN-SH2000-A1B2C3D4",
      installDate: "2023-01-15",
      warrantyEnd: "2025-01-15",
      customer: "Tech Innovations Inc.",
    },
    {
      id: "DEV002",
      name: "Smart Gateway X",
      model: "SG-500",
      serialNumber: "SN-SG500-E5F6G7H8",
      installDate: "2023-03-20",
      warrantyEnd: "2025-03-20",
      customer: "Global Logistics Solutions",
    },
    {
      id: "DEV003",
      name: "IoT Node Beta",
      model: "IN-100",
      serialNumber: "SN-IN100-I9J0K1L2",
      installDate: "2023-05-10",
      warrantyEnd: "2025-05-10",
      customer: "City Wide Utilities",
    },
    {
      id: "DEV004",
      name: "Environmental Monitor Pro",
      model: "EM-700",
      serialNumber: "SN-EM700-M3N4O5P6",
      installDate: "2023-07-22",
      warrantyEnd: "2025-07-22",
      customer: "Green Earth Farming",
    },
    {
      id: "DEV005",
      name: "Asset Tracker V2",
      model: "AT-V2",
      serialNumber: "SN-ATV2-Q7R8S9T0",
      installDate: "2023-09-01",
      warrantyEnd: "2025-09-01",
      customer: "Fleet Management Corp.",
    },
    {
      id: "DEV006",
      name: "Industrial Controller 3000",
      model: "IC-3000",
      serialNumber: "SN-IC3000-U1V2W3X4",
      installDate: "2023-11-05",
      warrantyEnd: "2025-11-05",
      customer: "Manufacturing Innovations Ltd.",
    },
  ])

  const [formData, setFormData] = useState({
    name: "",
    model: "",
    serialNumber: "",
    installDate: "",
    warrantyEnd: "",
    customer: "",
  })

  const handleAddDevice = () => {
    setEditingDevice(null)
    setFormData({
      name: "",
      model: "",
      serialNumber: "",
      installDate: "",
      warrantyEnd: "",
      customer: "",
    })
    setIsModalOpen(true)
  }

  const handleEditDevice = (device: any) => {
    setEditingDevice(device)
    setFormData({
      name: device.name,
      model: device.model,
      serialNumber: device.serialNumber,
      installDate: device.installDate,
      warrantyEnd: device.warrantyEnd,
      customer: device.customer,
    })
    setIsModalOpen(true)
  }

  const handleDeleteDevice = (device: any) => {
    setDeletingDevice(device)
    setIsDeleteConfirmOpen(true)
  }

  const confirmDelete = () => {
    setDevices(devices.filter((d) => d.id !== deletingDevice.id))
    setIsDeleteConfirmOpen(false)
    setDeletingDevice(null)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingDevice) {
      setDevices(devices.map((d) => (d.id === editingDevice.id ? { ...d, ...formData } : d)))
    } else {
      const newDevice = {
        id: `DEV${String(devices.length + 1).padStart(3, "0")}`,
        ...formData,
      }
      setDevices([...devices, newDevice])
    }
    setIsModalOpen(false)
  }

  return (
    <div className="flex-1 p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Device Management</h1>
      </div>

      <div className="bg-white rounded-lg border">
        <div className="p-6 flex items-center justify-between border-b">
          <h2 className="text-xl font-semibold">Device List</h2>
          <div className="flex gap-3">
            <div className="relative">
              <svg
                className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              <input
                type="text"
                placeholder="Search devices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button
              onClick={handleAddDevice}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center gap-2"
            >
              <span>+</span>
              Add Device
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Device ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Device Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Model
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Serial Number
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Install Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Warranty End
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Customer
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {devices.map((device) => (
                <tr key={device.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.model}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.serialNumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.installDate}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.warrantyEnd}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{device.customer}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center gap-3">
                      <button onClick={() => handleEditDevice(device)} className="text-blue-600 hover:text-blue-800">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                          />
                        </svg>
                      </button>
                      <button onClick={() => handleDeleteDevice(device)} className="text-red-600 hover:text-red-800">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                          />
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="px-6 py-4 border-t flex items-center justify-between">
          <p className="text-sm text-gray-500">Showing 6 of 6 devices</p>
          <div className="flex gap-2">
            <button className="px-3 py-1 text-sm border rounded hover:bg-gray-50 text-gray-400" disabled>
              Previous
            </button>
            <button className="px-3 py-1 text-sm border rounded hover:bg-gray-50 text-gray-400" disabled>
              Next
            </button>
          </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold mb-4">{editingDevice ? "Edit Device" : "Add New Device"}</h3>
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Device Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Model</label>
                  <input
                    type="text"
                    required
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Serial Number</label>
                  <input
                    type="text"
                    required
                    value={formData.serialNumber}
                    onChange={(e) => setFormData({ ...formData, serialNumber: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Install Date</label>
                  <input
                    type="date"
                    required
                    value={formData.installDate}
                    onChange={(e) => setFormData({ ...formData, installDate: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Warranty End</label>
                  <input
                    type="date"
                    required
                    value={formData.warrantyEnd}
                    onChange={(e) => setFormData({ ...formData, warrantyEnd: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Customer</label>
                  <input
                    type="text"
                    required
                    value={formData.customer}
                    onChange={(e) => setFormData({ ...formData, customer: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                  {editingDevice ? "Update" : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Confirm Delete</h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete device <strong>{deletingDevice?.name}</strong>? This action cannot be
              undone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setIsDeleteConfirmOpen(false)}
                className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button onClick={confirmDelete} className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"

export default function TicketOverviewContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingTicket, setEditingTicket] = useState<any>(null)
  const [tickets, setTickets] = useState([
    {
      id: "TKT-001",
      title: "Network Connectivity Issue",
      deviceName: "Router-B",
      priority: "High",
      status: "Open",
      assignedTo: "Alice Johnson",
      createdAt: "2023-10-26",
    },
    {
      id: "TKT-002",
      title: "Software Installation Failure",
      deviceName: "Laptop-User1",
      priority: "Medium",
      status: "In Progress",
      assignedTo: "Bob Williams",
      createdAt: "2023-10-25",
    },
    {
      id: "TKT-003",
      title: "Email Configuration Error",
      deviceName: "Mail-Server",
      priority: "Low",
      status: "Resolved",
      assignedTo: "Alice Johnson",
      createdAt: "2023-10-24",
    },
    {
      id: "TKT-004",
      title: "Printer Malfunction",
      deviceName: "Printer-HR",
      priority: "Medium",
      status: "Open",
      assignedTo: "Charlie Brown",
      createdAt: "2023-10-23",
    },
    {
      id: "TKT-005",
      title: "VPN Connection Dropping",
      deviceName: "VPN-Client-2",
      priority: "High",
      status: "In Progress",
      assignedTo: "Bob Williams",
      createdAt: "2023-10-22",
    },
  ])

  const [formData, setFormData] = useState({
    title: "",
    deviceName: "",
    priority: "Medium",
    status: "Open",
    assignedTo: "",
  })

  const handleCreateTicket = () => {
    setEditingTicket(null)
    setFormData({
      title: "",
      deviceName: "",
      priority: "Medium",
      status: "Open",
      assignedTo: "",
    })
    setIsModalOpen(true)
  }

  const handleEditTicket = (ticket: any) => {
    setEditingTicket(ticket)
    setFormData({
      title: ticket.title,
      deviceName: ticket.deviceName,
      priority: ticket.priority,
      status: ticket.status,
      assignedTo: ticket.assignedTo,
    })
    setIsModalOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingTicket) {
      setTickets(tickets.map((t) => (t.id === editingTicket.id ? { ...t, ...formData } : t)))
    } else {
      const newTicket = {
        id: `TKT-${String(tickets.length + 1).padStart(3, "0")}`,
        ...formData,
        createdAt: new Date().toISOString().split("T")[0],
      }
      setTickets([...tickets, newTicket])
    }
    setIsModalOpen(false)
  }

  return (
    <div className="flex-1 p-8">
      <h1 className="text-2xl font-bold mb-6">Ticket Management</h1>

      {/* Overview Stats */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Overview</h2>
        <div className="grid grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg border">
            <div className="flex items-start justify-between mb-2">
              <div className="text-gray-600 text-sm">Total Tickets</div>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1">15</div>
            <div className="text-xs text-gray-500">Across all categories</div>
          </div>

          <div className="bg-white p-6 rounded-lg border">
            <div className="flex items-start justify-between mb-2">
              <div className="text-gray-600 text-sm">Open Tickets</div>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1">6</div>
            <div className="text-xs text-gray-500">Requiring immediate attention</div>
          </div>

          <div className="bg-white p-6 rounded-lg border">
            <div className="flex items-start justify-between mb-2">
              <div className="text-gray-600 text-sm">In Progress</div>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1">4</div>
            <div className="text-xs text-gray-500">Currently being worked on</div>
          </div>

          <div className="bg-white p-6 rounded-lg border">
            <div className="flex items-start justify-between mb-2">
              <div className="text-gray-600 text-sm">Resolved Last 7 Days</div>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1">0</div>
            <div className="text-xs text-gray-500">Closed successfully</div>
          </div>
        </div>
      </div>

      {/* Chart and Actions Section */}
      <div className="bg-white p-6 rounded-lg border mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-base font-semibold mb-1">Tickets by Status</h3>
            <p className="text-sm text-gray-500">Distribution of tickets across different states.</p>
          </div>
        </div>

        <div className="flex items-end justify-center gap-8 h-64 mb-8">
          {/* Open - Blue - 6 tickets */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-1 items-end h-48">
              <div className="w-10 bg-blue-500 rounded-t" style={{ height: "170px" }}></div>
              <div className="w-10 bg-blue-500 rounded-t" style={{ height: "175px" }}></div>
              <div className="w-10 bg-blue-500 rounded-t" style={{ height: "180px" }}></div>
              <div className="w-10 bg-blue-500 rounded-t" style={{ height: "185px" }}></div>
            </div>
            <span className="text-sm text-gray-600 font-medium">Open</span>
          </div>

          {/* In Progress - Green - 4 tickets */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-1 items-end h-48">
              <div className="w-10 bg-green-500 rounded-t" style={{ height: "120px" }}></div>
              <div className="w-10 bg-green-500 rounded-t" style={{ height: "125px" }}></div>
              <div className="w-10 bg-green-500 rounded-t" style={{ height: "130px" }}></div>
              <div className="w-10 bg-green-500 rounded-t" style={{ height: "135px" }}></div>
            </div>
            <span className="text-sm text-gray-600 font-medium">In Progress</span>
          </div>

          {/* Pending - Orange - 3 tickets */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-1 items-end h-48">
              <div className="w-10 bg-orange-500 rounded-t" style={{ height: "90px" }}></div>
              <div className="w-10 bg-orange-500 rounded-t" style={{ height: "95px" }}></div>
              <div className="w-10 bg-orange-500 rounded-t" style={{ height: "100px" }}></div>
              <div className="w-10 bg-orange-500 rounded-t" style={{ height: "105px" }}></div>
            </div>
            <span className="text-sm text-gray-600 font-medium">Pending</span>
          </div>

          {/* Resolved - Purple - 2 tickets */}
          <div className="flex flex-col items-center gap-2">
            <div className="flex gap-1 items-end h-48">
              <div className="w-10 bg-purple-500 rounded-t" style={{ height: "60px" }}></div>
              <div className="w-10 bg-purple-500 rounded-t" style={{ height: "65px" }}></div>
              <div className="w-10 bg-purple-500 rounded-t" style={{ height: "70px" }}></div>
              <div className="w-10 bg-purple-500 rounded-t" style={{ height: "75px" }}></div>
            </div>
            <span className="text-sm text-gray-600 font-medium">Resolved</span>
          </div>
        </div>

        {/* Recent Tickets Tabs and Actions */}
        <div className="flex items-center justify-between border-t pt-6">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab("all")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "all" ? "bg-gray-100 font-medium" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              All Tickets
            </button>
            <button
              onClick={() => setActiveTab("my")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "my" ? "bg-gray-100 font-medium" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              My Tickets
            </button>
            <button
              onClick={() => setActiveTab("assigned")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "assigned" ? "bg-gray-100 font-medium" : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              Assigned to Me
            </button>
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search tickets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 border rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <svg
                className="absolute left-3 top-2.5 w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <button className="px-4 py-2 border rounded-lg text-sm flex items-center gap-2 hover:bg-gray-50">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
              Export
            </button>
            <button
              onClick={handleCreateTicket}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm flex items-center gap-2 hover:bg-blue-600"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Create New Ticket
            </button>
          </div>
        </div>
      </div>

      {/* Tickets Table */}
      <div className="bg-white rounded-lg border">
        <div className="p-6 flex items-center justify-between border-b">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab("all")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "all" ? "bg-gray-100 font-medium" : "text-gray-600"
              }`}
            >
              All Tickets
            </button>
            <button
              onClick={() => setActiveTab("my")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "my" ? "bg-gray-100 font-medium" : "text-gray-600"
              }`}
            >
              My Tickets
            </button>
            <button
              onClick={() => setActiveTab("assigned")}
              className={`px-4 py-2 text-sm rounded ${
                activeTab === "assigned" ? "bg-gray-100 font-medium" : "text-gray-600"
              }`}
            >
              Assigned to Me
            </button>
          </div>
          <div className="flex gap-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search tickets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 border rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <svg
                className="absolute left-3 top-2.5 w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <button className="px-4 py-2 border rounded-lg text-sm flex items-center gap-2 hover:bg-gray-50">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
              Export
            </button>
            <button
              onClick={handleCreateTicket}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm flex items-center gap-2 hover:bg-blue-600"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Create New Ticket
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ticket ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Title</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Device Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priority</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assigned To</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Created At</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {tickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm">{ticket.id}</td>
                  <td className="px-6 py-4 text-sm">{ticket.title}</td>
                  <td className="px-6 py-4 text-sm">{ticket.deviceName}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        ticket.priority === "High"
                          ? "bg-red-100 text-red-700"
                          : ticket.priority === "Medium"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {ticket.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        ticket.status === "Open"
                          ? "bg-blue-100 text-blue-700"
                          : ticket.status === "In Progress"
                            ? "bg-green-100 text-green-700"
                            : "bg-purple-100 text-purple-700"
                      }`}
                    >
                      {ticket.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">{ticket.assignedTo}</td>
                  <td className="px-6 py-4 text-sm">{ticket.createdAt}</td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => handleEditTicket(ticket)}
                      className="text-blue-600 hover:text-blue-800"
                      title="Edit"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                        />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="px-6 py-4 flex items-center justify-between border-t">
          <button className="px-4 py-2 text-sm text-gray-600 disabled:opacity-50" disabled>
            Previous
          </button>
          <div className="flex gap-2">
            <button className="px-3 py-1 text-sm bg-blue-500 text-white rounded">1</button>
            <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded">2</button>
            <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded">3</button>
          </div>
          <button className="px-4 py-2 text-sm text-blue-500">Next</button>
        </div>
      </div>

      {/* Modal for Create/Edit Ticket */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <h3 className="text-xl font-bold mb-4">{editingTicket ? "Edit Ticket" : "Create New Ticket"}</h3>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Device Name</label>
                  <input
                    type="text"
                    required
                    value={formData.deviceName}
                    onChange={(e) => setFormData({ ...formData, deviceName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                      className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Open">Open</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Resolved">Resolved</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Assigned To</label>
                  <input
                    type="text"
                    required
                    value={formData.assignedTo}
                    onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
                    className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                  {editingTicket ? "Update" : "Create"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

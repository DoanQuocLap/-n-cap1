"use client"

import { useState } from "react"

export default function RolePermissionsContent() {
  const [selectedUser, setSelectedUser] = useState("USR001")
  const [status, setStatus] = useState("Active")
  const [roles, setRoles] = useState({
    administrator: false,
    editor: true,
    viewer: true,
    moderator: false,
    analyst: false,
    support: false,
  })

  const users = [
    { id: "USR001", name: "Alice Smith", email: "alice.smith@example.com" },
    { id: "USR002", name: "Bob Johnson", email: "bob.johnson@example.com" },
    { id: "USR003", name: "Charlie Brown", email: "charlie.brown@example.com" },
    { id: "USR004", name: "Diana Prince", email: "diana.prince@example.com" },
  ]

  const handleRoleChange = (role: keyof typeof roles) => {
    setRoles({ ...roles, [role]: !roles[role] })
  }

  const handleSave = () => {
    alert(
      `Roles updated for ${users.find((u) => u.id === selectedUser)?.name}!\n\nStatus: ${status}\nRoles: ${Object.entries(
        roles,
      )
        .filter(([_, checked]) => checked)
        .map(([role]) => role)
        .join(", ")}`,
    )
  }

  const handleReset = () => {
    setStatus("Active")
    setRoles({
      administrator: false,
      editor: true,
      viewer: true,
      moderator: false,
      analyst: false,
      support: false,
    })
  }

  return (
    <div className="flex-1 p-8 overflow-auto">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border p-8">
          <h2 className="text-2xl font-bold mb-8">Role Permissions</h2>

          {/* User Selection */}
          <div className="mb-8">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select User</label>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name} ({user.email})
                </option>
              ))}
            </select>
          </div>

          {/* Account Status & Roles */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Account Status & Roles</h3>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Status Dropdown */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>

              {/* Roles Checkboxes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Roles</label>
                <div className="grid grid-cols-2 gap-4">
                  {/* Left Column */}
                  <div className="space-y-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.administrator}
                        onChange={() => handleRoleChange("administrator")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Administrator</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.viewer}
                        onChange={() => handleRoleChange("viewer")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Viewer</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.analyst}
                        onChange={() => handleRoleChange("analyst")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Analyst</span>
                    </label>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.editor}
                        onChange={() => handleRoleChange("editor")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Editor</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.moderator}
                        onChange={() => handleRoleChange("moderator")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Moderator</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={roles.support}
                        onChange={() => handleRoleChange("support")}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <span className="text-sm">Support</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="mt-8 flex justify-end gap-4">
              <button onClick={handleReset} className="px-6 py-2 border rounded-lg hover:bg-gray-50">
                Reset
              </button>
              <button onClick={handleSave} className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

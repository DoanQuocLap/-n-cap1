"use client"

import { useState } from "react"
import Login from "@/components/auth/login"
import Register from "@/components/auth/register"
import ForgotPassword from "@/components/auth/forgot-password"
import LayoutWithSidebar from "@/components/layout-with-sidebar"
import DashboardContent from "@/components/dashboard-content"
import DeviceManagementContent from "@/components/device-management-content"
import TicketOverviewContent from "@/components/ticket-overview-content"
import UserManagementContent from "@/components/user-management-content"
import ProfileContent from "@/components/profile-content"
import RolePermissionsContent from "@/components/role-permissions-content"
import ReportsSummaryContent from "@/components/reports-summary-content"
import SettingsContent from "@/components/settings-content"

type Page =
  | "login"
  | "register"
  | "forgot-password"
  | "dashboard"
  | "device-management"
  | "ticket-overview"
  | "user-management"
  | "role-permissions"
  | "profile"
  | "reports-summary"
  | "settings"

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [currentPage, setCurrentPage] = useState<Page>("login")

  const handleLogin = () => {
    setIsAuthenticated(true)
    setCurrentPage("dashboard")
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setCurrentPage("login")
  }

  // Authentication pages (no sidebar)
  if (!isAuthenticated) {
    return (
      <main className="min-h-screen">
        {currentPage === "login" && <Login onNavigate={setCurrentPage} onLoginSuccess={handleLogin} />}
        {currentPage === "register" && <Register onNavigate={setCurrentPage} />}
        {currentPage === "forgot-password" && <ForgotPassword onNavigate={setCurrentPage} />}
      </main>
    )
  }

  // Authenticated pages (with sidebar)
  return (
    <LayoutWithSidebar currentPage={currentPage} onNavigate={setCurrentPage} onLogout={handleLogout}>
      {currentPage === "dashboard" && <DashboardContent onNavigate={setCurrentPage} />}
      {currentPage === "user-management" && <UserManagementContent />}
      {currentPage === "role-permissions" && <RolePermissionsContent />}
      {currentPage === "device-management" && <DeviceManagementContent />}
      {currentPage === "ticket-overview" && <TicketOverviewContent />}
      {currentPage === "reports-summary" && <ReportsSummaryContent />}
      {currentPage === "settings" && <SettingsContent />}
      {currentPage === "profile" && <ProfileContent onNavigate={setCurrentPage} />}
    </LayoutWithSidebar>
  )
}
